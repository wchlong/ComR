package test;

import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

public class Ont_Axiom {
	
	
	
	OWLOntology ont;
	public Ont_Axiom(OWLOntology ont){
		this.ont=ont;
	}
	
	
	 public Set<OWLAxiom>  getnonELAxiom()
	  {
		
		   Set<OWLAxiom> nonELaxiom=new HashSet();
	     int n = 0;
	    ELAxiomVisitor visitor = new ELAxiomVisitor();
	    for (OWLAxiom ax : ont.getTBoxAxioms(true)) {
	      ax.accept(visitor);
	      if (!visitor.isEL())//�������EL����������NonELaxiom��
	      {   n++;
	      nonELaxiom.add(ax);
	      System.out.println("non-EL axiom "+n+":");
	      System.out.println(ax);
	      }
	    }
	    /*
	    for (OWLAxiom ax : originalOnt.getRBoxAxioms(true)) {
	      ax.accept(visitor);
	      if (!visitor.isEL())//�������EL����������NonELaxiom��
	      {
	    	  n++;
	      nonELaxiom.add(ax);
	     }
	    } 
	 // System.out.println("\tof which " + n + " are EL\n");
	//	System.out.println("nonELaxiom��   "+ nonELaxiom.size());
	 */   
		return nonELaxiom;

	  }	
	

}
