package test;

import java.io.File;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.semanticweb.HermiT.Reasoner;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.util.DLExpressivityChecker;
import org.semanticweb.owlapi.util.InferredOntologyGenerator;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		
		File pro_v117=new File("D:/Ontology/pro_v1.17.obo");//EL
		File pro_v122=new File("D:/Ontology/pro_v1.22.obo");//EL
		File pro_inf160=new File("D:/Ontology/pro-inferred_v16.0.obo");//non_el:8
			
	//	File hrdo_file=new File("E:/Ontology/hrdo.owl");// Problem parsing file:/E:/Ontology/hrdo.owl
	//	File ICD_file=new File("E:/Ontology/ICD9CM.ttl");//Could not load imported ontology:
		//File hino_file=new File("E:/Ontology/hino_vVision_Release__1038.owl");//No! Could not load imported ontology
		//File hugo_file=new File("E:/Ontology/Hugo_July12_2010_vJuly2010.owl");//No! Problem parsing file
		//File clov_file=new File("E:/Ontology/clov2130.owl");//No Could not load imported ontology	
		//File obi_file=new File("D:/Ontology/merged-obi-comments_v2012-03-29.owl");// No error getPrincipal() outofmemmory
		//File FMA_file=new File("E:/Ontology/fmaOwlFullComponent_2_0.owl");//Could not load imported ontology:
		//File bone_file=new File("E:/Ontology/bonedysplasia.owl");//Could not load imported ontology:
		
		//File cco_file=new File("E:/Ontology/cco_v201.obo");	//5d,java.lang.OutOfMemoryError: Java heap space
      //File GeXO_file=new File("E:/Ontology/GeXO_v1.01.obo");// 5d,not complete
		
			File NCI_file1=new File("D:/Ontology/ThesaurusInf_13.02dOWL/ThesaurusInferred.owl");//256M outofmemmory  // Tbox: 357054 RBox:13   [Axioms: 1566007 Logical Axioms: 357055]
		
		//File NCI_file2=new File("E:/Ontology/nci/NCI.owl");//156M / Tbox: 130928 RBox:19
			File nci_file4=new File("D:/Ontology/Thesaurus_12.04e-Processed.owl");//  [Axioms: 1188705 Logical Axioms: 182366]Non_EL axioms: 65
			File NCI_file5=new File("D:/Ontology/NCITNCBO_14_03e.owl");//[Axioms: 1390339 Logical Axioms: 226038]non-el 67
			
			File NCI_file3=new File("D:/Ontology/Thesaurus_10_03.owl");// [Axioms: 1093733 Logical Axioms: 111739] TBox: 111732 RBox: 19  Non_EL axioms: 4541
			
			//File biomodel_file=new File("E:/Ontology/biomodels-21.owl");//outofmemmory
			//File OBO_file=new File("E:/Ontology/OBO.owl");	//all axioms: 20157    Non_EL axiom: 1232 non_EL module:20094
			
			
		
		
		//	File go_file=new File("D:/Ontology/go_daily-termdb.owl/go_daily-termdb.owl");//EL  
		File chebi_file=new File("E:/Ontology/chebi.obo");//EL ontology [Axioms: 641802 Logical Axioms: 118878]�ֽ�ʱ�䣺 1269046ms
			File ICNP_file=new File("D:/Ontology/ICNP2011_v2011.owl");//ok
		File protein2_file=new File("D:/Ontology/pro_reasoned_v34.0.obo");//ok
			File galen_file=new File("D:/Ontology/full-galen_v1.1.owl");// ok  
		
		File DermLex_file=new File("E:/Ontology1/DermLex_Ver_1_0.owl");// ok
	//	File EDAM_file=new File("E:/Ontology1/EDAM_1.3.owl");// ok	
//		
		File ero_file=new File("D:/Ontology/ero.owl");//ok
		File HuPSON_phenotype_file=new File("E:/Ontology1/HuPSON_v092013_merged.owl");//ok

		// 4.27  new ontology
	//  // //????:
	//	File bao_file=new File("E:/Ontology/bao_complete.owl");// �о������⣬�߼�������ĿС�ڷֽ��ȡ�ù�����Ŀ���ǲ����߼����ص��߼������в���������Ĺ���
	
		//	File bao_file=new File("E:/Ontology1/bao_complete.owl");
	//	File amphibian_file=new File("E:/Ontology1/amphibian_taxonomy.OBO");//EL 

	//	File BrendaTissue_file=new File("E:/Ontology1/BrendaTissue.OBO");//EL
	
	//	File BrendaTissue_file=new File("E:/Ontology1/BrendaTissue.OBO");//EL
	//	File brucellosis_file=new File("E:/Ontology1/brucellosis.owl");// imported
	//	File cmo_xp_file=new File("E:/Ontology1/cmo-xp.obo");//EL
	
	
	//	File EMAP_file=new File("E:/Ontology1/EMAP.obo");//ok
//		
		
		
		
	//	File HL7_CUIS_file=new File("E:/Ontology1/HL7-CUIS.owl");//EL
	//	File hao_file=new File("E:/Ontology1/hao.owl");//EL
	//	File human_file=new File("E:/Ontology1/human-dev-anat-abstract.obo");//EL
	//	File human_dev_file=new File("E:/Ontology1/human-dev-anat-staged_v1.3.obo");//EL
	//	File human_phenotype_file=new File("E:/Ontology1/human-phenotype-ontology.obo");//EL
	//	File HuPSON_phenotype_file=new File("E:/Ontology1/HuPSON_v092013_merged.owl");//ok
	
	
	//	File IDOMAL_file=new File("E:/Ontology1/IDOMAL_1.3.7.obo");//EL
	//	File KB_Bio_file=new File("E:/Ontology1/KB_Bio_101.ofn");//   java.lang.OutOfMemoryError: Java heap space
	//	File mammalian_file=new File("E:/Ontology1/mammalian_phenotype.obo");//EL
	//	File medaka_file=new File("E:/Ontology1/medaka_ontology.obo");//EL
	//	File miro_file=new File("E:/Ontology1/miro_release.obo");//EL
	//	File nif_file=new File("D:/Ontology/nif.owl");//Could not load imported ontology:
	//File NIF_file=new File("E:/Ontology1/NIF-Cell.owl");//��Ҫ�����ⲿ���塣�߼���������AD�еĹ�����������
   //	File NIFDys_file=new File("E:/Ontology1/NIF-Dysfunction.owl");// ��Ҫ�����ⲿ���塣�߼���������AD�еĹ�����������
   //   File NIGO_file=new File("E:/Ontology1/NIGO.obo");//EL
		
		
		
		File wine_file=new File("D:/Ontology/wine.owl");//
		//File upheno_file=new File("D:/Ontology/upheno.owl");//parsing problem 
		
		//File pma_file=new File("D:/Ontology/pma.owl");//AL
		//File OMIT_file=new File("D:/Ontology/OMIT.owl");//SRI(D) 
		//File atol_v6_file=new File("D:/Ontology/atol_v6.owl");//ALE(D)
		File tao_file=new File("D:/Ontology/tao.obo");//ok
		File SYN_file=new File("D:/Ontology/SYN.owl");//SHI
		//File soxp_file=new File("D:/Ontology/so-xp.owl");//SHI
		//File planttraitontology_file=new File("D:/Ontology/plant-trait-ontology.obo");//ALE
		//File PlantExperimentalAssayOntology_file=new File("D:/Ontology/PlantExperimentalAssayOntology.owl");//ALCHQ(D)

		//File ordo_orphanet_file=new File("D:/Ontology/ordo_orphanet.owl");//ALE(D)
		//File OntolUrgences_file=new File("D:/Ontology/OntolUrgences_v3.0.4.owl");//SRIQ(D)
		//File ontoad_file=new File("D:/Ontology/ontoad.owl");//ALH
		//File oae_file=new File("D:/Ontology/oae.owl");//ALCH
				//	File NIFSubcellular_file=new File("D:/Ontology/NIF-Subcellular.owl");//ALC
		//File mouse_file=new File("D:/Ontology/mouse.obo");//ALE+
	//File ext_file=new File("D:/Ontology/ext.owl");//SRIQ	
		File profile=new File("D:/Ontology/pro_reasoned.obo");//�����ظ�
	//	File psi_file=new File("E:/Ontology1/psi-ms.obo");//EL
	//	File Radlex_file=new File("E:/Ontology1/Radlex311.owl");// Problem parsing file:
	//File idoden_file=new File("E:/Ontology1/idoden_beta0.15.owl");/ok
	//	File rexo_file=new File("E:/Ontology1/rexo.obo");//̫�󣬴���֤
	//	File FAOnt_file=new File("E:/Ontology1/V3.0FAOntology.rdf-xml.owl");//EL
	//	File FAOnt_file=new File("E:/Ontology1/V3.0FAOntology.rdf-xml.owl");
		
		
		//File oo_file=new File("D:/Ontology/oo.owl");//RDFXMLParser.parse
		//File dronfull_file=new File("D:/Ontology/dron-full.owl"); // .RDFXMLParser.parse	
		//File dronfull_file=new File("D:/Ontology/dron-full.owl"); // .RDFXMLParser.parse	
	//			File DDO_v1_file=new File("D:/Ontology/DDO_v1.owl");// import erro
//		File iceci_file=new File("E:/Ontology1/iceci.owl");//EL
		//File Celllineontologyv20_file=new File("D:/Ontology/Cell line ontology v2.0.owl");// ALCH(D) û�з�EL����������
		//File caDSR_vs_file=new File("D:/Ontology/caDSR_vs.owl");//AL
		//File bcgo_merged_inferred_file=new File("D:/Ontology/bcgo_merged_inferred.owl");//SROIN(D
		//	File BIRNLex_file=new File("E:/Ontology1/BIRNLex.owl");//EL
		//File caDSR_file=new File("D:/Ontology/caDSR_vs.owl");//AL logical 
		//File apa_file=new File("D:/Ontology/apa-31-10-2014_13-30.owl");//AL logical axiom 0	
	//File v3FAOntology_file=new File("D:/Ontology/V3.0FAOntology.rdf-xml.owl");//AL	
		//File ext_file=new File("D:/Ontology/ext.owl");//SRIQ OutOfMemoryError: Java heap space
		//File Exo_CSEOv_file=new File("D:/Ontology/Exo-CSEOv1.2_BFO_FINAL_merged_2.owl");// SRI(D)	
		// File flopo_file=new File("E:/Ontology/flopo-classified.owl");//classified   EL ontology  [Axioms: 87708 Logical Axioms: 31902]
		//	File rat_file=new File("E:/Ontology1/rat_strain.obo");//EL
		//File plant_file=new File("D:/Ontology/plant-trait-ontology.obo");//ALE
		//File ontoad_file=new File("D:/Ontology/ontoad.owl");//ALH
		//	File ordo_file=new File("D:/Ontology/ordo_orphanet.owl");//ALE(D)
		
		//File mouse_file=new File("D:/Ontology/mouse.obo");//EL
		//File v3FAOntology_file=new File("D:/Ontology/V3.0FAOntology.rdf-xml.owl");//AL
		

		//File ncro_file=new File("D:/Ontology/ncro.owl");//RDF parse erro
		//File matrRockIgneous_file=new File("D:/Ontology/matrRockIgneous.owl");//RDF parse erro
		//		File matrOrganicCompound_file=new File("D:/Ontology/matrOrganicCompound.owl");//RDF parse erro
		//File matrNaturalResource_file=new File("D:/Ontology/matrNaturalResource.owl");//RDF parse erro
		//File matrMineral_file=new File("D:/Ontology/matrMineral.owl");//RDF parse erro
		// File matrCompound_file=new File("D:/Ontology/matrCompound.owl");//RDF parse erro
		// File matr_file=new File("D:/Ontology/matr.owl");//RDF parse erro
		//File enanomapper_file=new File("D:/Ontology/enanomapper.owl");//RDF parse erro
		//		File snpontology_full_file=new File("D:/Ontology/snpontology_full.owl");//RDF parse erro
		//		File EFO_inferred_file=new File("D:/Ontology/EFO_inferred.owl");//org.semanticweb.HermiT.datatypes.UnsupportedDatatypeException
		//File dronfull_file=new File("D:/Ontology/dron-full.owl"); // parse erro
		//File cl_file=new File("D:/Ontology/cl.owl");// parse erro
		//		File dcm_file=new File("E:/Ontology1/dcm.owl");// imported
//		File CTCAE_xp_file=new File("E:/Ontology1/CTCAE_4.03_2010-06-14.owl");//imorted
		//	File drug_file=new File("D:/Ontology/dron-full.owl");// parsing erro
       //File DDO_v1_file=new File("D:/Ontology/DDO_v1.owl");//Could not load imported ontology
	   //File enanomapper_file=new File("D:/Ontology/enanomapper.owl");//parse erro	
		//File biomodel_file=new File("D:/Ontology/biomodels-21.owl");//outofmemmory
		//File EFO_file=new File("D:/Ontology/EFO_inferred.owl");// Problem parsing file:/E:/Ontology1/EFO_inferred.owl	
		//	File NPO_file=new File("E:/Ontology/NPOntology01_vunknown.owl");// No! [Axioms: 234994 Logical Axioms: 159992] OutOfMemoryError: Java heap space
		//	File MaHCO_file=new File("E:/Ontology1/MaHCO.owl");//��Ҫ�����ⲿ���塣�߼���������AD�еĹ�����������
		//File bone_file=new File("D:/Ontology/bonedysplasia.owl");//loading  too long
		//File sweetAll_file=new File("D:/Ontology/sweetAll.owl");//RDFXMLParser.java:126

		
		//File pizza_file=new File("D:/Ontology/pizza.owl");//
		//File people_file=new File("D:/Ontology/people.owl");//-Xms1024m -Xmx4096m
		
		//File idoden_file=new File("D:/Ontology/idoden_beta0.15.owl");// 1. ok
		
		
		
		
		
		
		System.out.println("loading ontology....");
		 OWLOntologyManager	m=OWLManager.createOWLOntologyManager();
	     OWLOntology o=m.loadOntologyFromOntologyDocument( tao_file);
	     System.out.println("loading completed!");
	     System.out.println("original ontology:");
	     
	     System.out.println(o);
	     System.out.println( "non_EL axioms----------------- ");
	     Ont_Axiom ont_A=new Ont_Axiom(o);
	     ont_A.getnonELAxiom();
	     
	    /*
	     //determining DL
	     DLExpressivityChecker checker = new DLExpressivityChecker(Collections.singleton(o));		 
		  System.out.println(checker.getConstructs().toString());
		  System.out.println(checker.getDescriptionLogicName());
	     
	     System.out.println( "class: "+o.getClassesInSignature().size());
	     System.out.println( "class with imported classes: "+o.getClassesInSignature(true).size());
	 
	     */
	     
	     /*   System.out.println( "logical axioms: "+o.getLogicalAxiomCount());
	     System.out.println("-----------------------------------");
	     System.out.println("TBox: "+o.getTBoxAxioms(true).size());
	     System.out.println("RBox: "+o.getRBoxAxioms(true).size()) ;

	 
	     System.out.println("----------------------------------------------");	
    	 System.out.println("  Non_EL axioms: "+  getNon_ELAxiom(o).size());
	  */
	  
	  // classify with hermiT
    	 /*
	     System.out.println("----------------------------------------------");	
    	 System.out.println("  classifying the original ontology with HermiT.....:");
		  Reasoner hermit= new Reasoner(o);
		  long tHermit = System.currentTimeMillis();
		    // hermit.classifyClasses();
		  hermit.precomputeInferences(InferenceType.CLASS_HIERARCHY);
		     tHermit = System.currentTimeMillis() - tHermit;
		     System.out.println("HermiT classifying original ontology�� " + tHermit + " milliseconds");
		     
		     hermit.dispose();
	   	   */
	     
    	 
    	 
    	// task decomposition 
	     
	     System.out.println("starting decomposing ontology....");
	     TaskDecopostion td=new TaskDecopostion(o);
	     System.out.println("decomposition completed!");
	     
	//     System.out.println("-----------------------------------");
	//     System.out.println("TaughtLogical axioms :  " +td.getTaughtCount());
	     
	//     System.out.println("-----------------------------------");
	 //    System.out.println("Axioms Count in AD:  "+ td.getAxiomsAfterAD());
	  
	      
	     System.out.println("-----------------------------------");
	     System.out.println("totals Atoms: "+td.adt.getAtoms().size());
	     System.out.println("non_EL Atoms: "+td.getnonELatomList().size());
	    
	     System.out.println("-----------------------------------");
	     System.out.println("all axioms: "+(o.getTBoxAxioms(true).size()+o.getRBoxAxioms(true).size()) +  "    Non_EL axiom: "+td.getNon_ELAxiom().size());
	     
	   
	     
	     
	     System.out.println("-----------------------------------");
	     System.out.println("non_EL module:"+td.getNonELModule().size());
	     
	     System.out.println("-----------------------------------");
	     System.out.println("EL module:"+td.getELModule().size());
	     System.out.println("-----------------------------------");
	     System.out.println("remaidering EL module:"+td.getRemainderEL().size());
	     
	     System.out.println("-----------------------------------");
	   
	     
	  
	     
	     
	       
	    // modular classification 
	     
	 /*   
	     System.out.println("-----------------------------------");
	     System.out.println("two threads:");
	     try{
			    
			    OWLOntologyManager man = OWLManager.createOWLOntologyManager();	
			   OWLOntology non_EL_Ontology = man.createOntology(td.getNonELModule());
				//   man.addAxioms(non_EL_Ontology, td.getNonELModule());
				   System.out.println("-----non_EL_Ontology------: "+ non_EL_Ontology);
				   
				   OWLOntologyManager manage = OWLManager.createOWLOntologyManager();	
				   OWLOntology el_ontology = manage.createOntology(td.getELModule());
				 //  manage.addAxioms(el_ontology, td.getELModule());
				   System.out.println("------el_ontology-----: "+ el_ontology);
				   
				   ReasonerThread non_EL_thread=new ReasonerThread(non_EL_Ontology,false,td.getRemainderEL());
				   ReasonerThread EL_thread=new ReasonerThread(el_ontology,true,td.getRemainderEL());
				   
				   non_EL_thread.start();
				   EL_thread.start();
			
			
	   
		
	    
	     
	     
	     }catch(Exception e){}
		
		
	     
	     /*
	     System.out.println("-----------------------------------");
	     System.out.println("single thread:");
	     SingleThread st=new SingleThread(td);
	     st.classify_Ontology();
	     System.out.println();
	    */
	     System.out.println("program completed!");
	     
	    
	}// end of main 
	
	   public static  Set<OWLAxiom>  getNon_ELAxiom(OWLOntology ont)
		  {
			
			 
			
		
			
			   Set<OWLAxiom> nonELaxiom=new HashSet();
		    int n = 0;
		    ELAxiomVisitor visitor = new ELAxiomVisitor();
		    for (OWLAxiom ax : ont.getTBoxAxioms(true)) {
		      ax.accept(visitor);
		      if (!visitor.isEL())//�������EL����������NonELaxiom��
		      {   n++;
		      nonELaxiom.add(ax);
		      }
		    }
		    for (OWLAxiom ax : ont.getRBoxAxioms(true)) {
		      ax.accept(visitor);
		      if (!visitor.isEL())//�������EL����������NonELaxiom��
		      {
		    	  n++;
		      nonELaxiom.add(ax);
		     }
		    } 
		
			return nonELaxiom;

		  }	
	
	
	
	
	
	
	

}
